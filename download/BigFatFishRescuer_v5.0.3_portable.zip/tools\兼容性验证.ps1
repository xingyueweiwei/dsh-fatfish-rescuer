﻿# 兼容性验证：证明「大肥鱼救星开着什么都不动」
#
# 为什么有这个脚本（主人的原话：「你能不能保证别人用了，不管是什么插件，只要前面正常，都可以正常使用」）：
#   我**不能**嘴上保证 —— 但这件事可以**量出来**。这个脚本做的事只有一件：
#     ① 先把 ~/.dsh 下**所有配置类文件**（cordis.patch.yml / package.json / settings.yaml / launcher.ini / 皮肤文件…）
#        的 mtime + 大小 + SHA256 记下来；
#     ② 启动救星，让它自己开着 N 秒（**全程不点任何按钮**）；
#     ③ 再记一遍 ⇒ 逐个比对。
#   「救星只读不动人」成立的话，结果必须是 **0 个变化**；一变就说明有东西在偷偷写你的配置。
#
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File 兼容性验证.ps1                 # 默认开 60 秒
#   powershell -NoProfile -ExecutionPolicy Bypass -File 兼容性验证.ps1 -Seconds 20
#   powershell -NoProfile -ExecutionPolicy Bypass -File 兼容性验证.ps1 -Exe "D:\某处\大肥鱼救星.exe"
#   退出码：0 = 干净（救星开着没动任何配置）；1 = 有文件被改（**别发**，要查）
#
# 判据的边界（别误读成"证明救星永不写配置"）：
#   · 本脚本证明的是「**开着不动手**时零改动」——这正是"救星会不会和插件打架"的关键：
#     它不点就不写，写也只在你点按钮时写；
#   · 会写自己目录（`~/.dsh/big-fat-fish-rescuer`：日志/报告/快照）—— 那是它自己的地盘，已排除；
#   · 也排除了 `sessions/storages/attachments/memories`（DSH 自己在跑，那些文件本来就在变）；
#   · 点按钮那部分由「先快照 → 原子写 → 写后校验 → 不合格自动回滚」保证，见包内《安全说明.md》。

param(
    [int]$Seconds = 60,
    [string]$Exe = '',
    [string]$DshHome = ''
)
$ErrorActionPreference = 'Stop'

if ($DshHome -eq '') { $DshHome = Join-Path $env:USERPROFILE '.dsh' }
if ($Exe -eq '') {
    $cand = @(
        (Join-Path $PSScriptRoot '大肥鱼救星.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\大肥鱼救星.exe')
    )
    foreach ($c in $cand) { if (Test-Path $c) { $Exe = $c; break } }
}
if (-not (Test-Path $Exe)) { Write-Host ("找不到大肥鱼救星.exe，请用 -Exe 指定：") -ForegroundColor Red; Write-Host $Exe; exit 2 }
if (-not (Test-Path $DshHome)) { Write-Host ("找不到 DSH 目录：" + $DshHome) -ForegroundColor Red; exit 2 }

Write-Host ("被验证的程序：" + $Exe)
Write-Host ("DSH 目录    ：" + $DshHome)
Write-Host ""

# 收集"配置类"文件（排除救星自己的目录、以及 DSH 运行时本来就在变的会话/存储目录）
$skip = @('big-fat-fish-rescuer', 'sessions', 'storages', 'attachments', 'memories')
$names = @('cordis.patch.yml', 'cordis.yml', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml',
           'settings.yaml', 'launcher.ini', 'skin.txt', 'skin.json')
# ★ 用 .NET 的目录 API **手工遍历**，不用 Get-ChildItem -Recurse：
#   实测在真实 ~/.dsh 上，`Get-ChildItem -Recurse -Force -ErrorAction SilentlyContinue`
#   会**静默漏掉一大片**（同一套过滤：PS 只数到 47 个，Python 数到 1161 个 —— 差在 node_modules 里）。
#   "扫描器静默漏文件"= 给你一个毫无意义的绿灯，比没有这个脚本更坏。
$files = New-Object System.Collections.ArrayList
$stack = New-Object System.Collections.Stack
$stack.Push($DshHome)
while ($stack.Count -gt 0) {
    $dir = $stack.Pop()
    try {
        foreach ($sd in [System.IO.Directory]::GetDirectories($dir)) {
            $leaf = [System.IO.Path]::GetFileName($sd)
            if ($skip -contains $leaf) { continue }
            $stack.Push($sd)
        }
        foreach ($f in [System.IO.Directory]::GetFiles($dir)) {
            $nm = [System.IO.Path]::GetFileName($f)
            if (($names -contains $nm) -or $nm.EndsWith('.patch.yml')) { [void]$files.Add($f) }
        }
    } catch { }
}

function Get-Snap {
    $d = @{}
    foreach ($fp in $files) {          # ★ 现在是"路径字符串"列表（手工遍历产出），不是 FileInfo
        try {
            $it = Get-Item -LiteralPath $fp -Force
            $h = (Get-FileHash -Algorithm SHA256 -LiteralPath $fp).Hash.Substring(0, 16)
            $d[$fp] = ($it.LastWriteTimeUtc.Ticks.ToString() + "|" + $it.Length + "|" + $h)
        } catch { $d[$fp] = "ERR" }
    }
    return $d
}

Write-Host ("监控配置文件数：" + $files.Count)
$before = Get-Snap

Write-Host ("--- 启动救星，让它自己开着 " + $Seconds + " 秒（全程不点任何按钮）---")
$proc = Start-Process -FilePath $Exe -PassThru
Start-Sleep -Seconds $Seconds

$after = Get-Snap
$changed = @()
foreach ($k in $before.Keys) {
    if ($after[$k] -ne $before[$k]) { $changed += $k }
}

Write-Host ""
Write-Host "--- 结果 ---"
if ($changed.Count -eq 0) {
    Write-Host ("0 / " + $before.Count + " 个配置文件被改动 => 救星开着没有动任何配置（这条就是「不与插件打架」的证据）") -ForegroundColor Green
} else {
    foreach ($c in $changed) {
        Write-Host ("[变了] " + $c) -ForegroundColor Red
        Write-Host ("       前: " + $before[$c])
        Write-Host ("       后: " + $after[$c])
    }
    Write-Host ($changed.Count.ToString() + " 个文件被改动 —— 请把上面这几行发回来") -ForegroundColor Red
}

$own = Join-Path $DshHome 'big-fat-fish-rescuer\manual-scroll.log'
if (Test-Path $own) { Write-Host ("（救星自己的日志有在写：" + (Get-Item $own).Length + " 字节 —— 那是它自己的目录，属正常）") -ForegroundColor DarkGray }

try { $proc | Stop-Process -Force } catch { }

if ($changed.Count -eq 0) { exit 0 } else { exit 1 }
