// ============================================================
//  大肥鱼救星 · 会话文件体检器（只读）
//
//  为什么要它：DSH 的 `session.jsonl.zstd` 是**多帧追加**的 zstd（每次追加一帧），
//  而 Node 的 `zstdDecompressSync` 只解**第一帧**、流式解码遇到第二帧就报
//  "Unknown frame descriptor"（本机实测：9.7MB 只解出 206 字节 / 2 行）。
//  所以必须**按魔数 28 B5 2F FD 切帧、逐帧解码**。
//
//  这一版吸收的是社区项目 `dsh-session-surgeon` 的**体检**部分（scan / inspect）：
//    · 帧数、解码成功/失败、尾部半截帧（torn）
//    · 行数、行类型直方图
//    · seq 连续性与**断档**（seq gap）
//    · 缺 message id 的行数
//    · 悬空 tool/call（有 call 没 result）
//    · 孤儿 .tmp
//  ★ 只读：绝不写盘、绝不改名、绝不"凭空补 seq"。修复留给人（或社区工具）。
//
//  用法：node session-inspect.cjs <文件或目录> [--json] [--limit N]
// ============================================================
"use strict";
const fs = require("fs");
const path = require("path");
const zlib = require("node:zlib");

const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd]);

function findMagic(buf) {
  const offs = [];
  let i = 0;
  while (true) {
    const j = buf.indexOf(MAGIC, i);
    if (j < 0) break;
    offs.push(j);
    i = j + 1;
  }
  return offs;
}

/** 逐帧解码：从每个魔数位置起，切片到"下一个魔数"，解不开就把切片往后延（魔数可能是载荷里的巧合） */
function decodeFrames(buf) {
  const offs = findMagic(buf);
  const out = { frames: 0, failed: 0, tornTail: false, text: "", errors: [] };
  if (offs.length === 0) { out.errors.push("没有 zstd 魔数（文件可能不是 zstd / 已损坏）"); return out; }
  let pos = offs[0];
  let k = offs.indexOf(pos);
  while (k >= 0 && pos < buf.length) {
    let ok = false;
    for (let attempt = 0; attempt < 6; attempt++) {
      const nextIdx = k + 1 + attempt;
      const end = nextIdx < offs.length ? offs[nextIdx] : buf.length;
      if (end <= pos) continue;
      const slice = buf.subarray(pos, end);
      try {
        const dec = zlib.zstdDecompressSync(slice);
        out.text += dec.toString("utf8");
        out.frames++;
        pos = end;
        k = nextIdx;
        ok = true;
        break;
      } catch (e) {
        if (attempt === 5) out.errors.push("偏移 " + pos + " 起解不开：" + (e && e.message ? e.message : String(e)));
      }
    }
    if (!ok) {
      out.failed++;
      // 只能判断"尾部半截帧"还是"中间坏帧"：如果 pos 已在文件后半段，倾向 torn
      out.tornTail = pos > buf.length * 0.5;
      break;
    }
  }
  return out;
}

function inspectFile(file) {
  const buf = fs.readFileSync(file);
  const fr = decodeFrames(buf);
  const lines = fr.text.split("\n").filter((l) => l.trim().length > 0);

  const types = Object.create(null);
  let seqSeen = 0, seqGap = 0, prevNext = null, firstSeq = null, lastSeqVal = null;
  let noMsgId = 0, toolCalls = 0, toolResults = 0;
  const callIds = new Set(), resultIds = new Set();
  const callSeq = new Map();     // callId → 它所在行的 seq（用于"尾部未回不算悬空"）
  let maxSeq = 0;
  let parseErrors = 0;

  // ★ 判据校准（2026-09-17 实测，别再凭猜）：
  //   · 普通行占 1 个 seq；**打包行**（带 `seq0`，如 text-chunks / tool-call-chunks）
  //     占 `1 + dt.length` 个 seq —— 用这条模型在 148,383 行上实测 **断档 0 处**；
  //     换成"打包行算 1"会虚报 87,630 处、"算 texts.length"会虚报 43,307 处。
  //   · 工具调用 id：`tool/call.data.callId`；**结果**的 id 在 `tool/result.data.message.source.callId`
  //     （我第一版按 `data.callId` 取结果 ⇒ 把 3,966 个正常调用全报成"悬空"）。
  const coverage = (o) => (o.seq0 !== undefined)
    ? 1 + ((o.data && Array.isArray(o.data.dt)) ? o.data.dt.length : 0)
    : 1;

  for (const line of lines) {
    let o = null;
    try { o = JSON.parse(line); } catch (e) { parseErrors++; continue; }
    const t = o && o.type ? String(o.type) : "(无 type)";
    types[t] = (types[t] || 0) + 1;

    const s = (o.seq !== undefined) ? o.seq : o.seq0;
    if (typeof s === "number") {
      seqSeen++;
      if (firstSeq === null) firstSeq = s;
      if (prevNext !== null && s !== prevNext) seqGap++;
      prevNext = s + coverage(o);
      lastSeqVal = s;
      if (s > maxSeq) maxSeq = s;
    }

    const d = o && o.data ? o.data : null;
    if (d && d.message && !d.message.id && t.indexOf("message") >= 0 && t.indexOf("tool") < 0) noMsgId++;
    if (t === "tool/call" && d && d.callId) { toolCalls++; callIds.add(String(d.callId)); callSeq.set(String(d.callId), typeof s === "number" ? s : 0); }
    if (t === "tool/result" && d && d.message && d.message.source && d.message.source.callId) {
      toolResults++; resultIds.add(String(d.message.source.callId));
    }
  }
  // ★ 避免误报：**最后一步还没回来的调用不算悬空** ——
  //   正在进行的会话（比如你自己正在说话）尾巴上天然会有 0~1 个未回调用。
  //   只统计"后面已经有更新的结果了、它却一直没回"的那种。
  const lastSeq = maxSeq;
  let dangling = 0;
  const danglingOld = [];
  for (const [id, seq] of callSeq) {
    if (resultIds.has(id)) continue;
    if (lastSeq - seq > 2000) { dangling++; if (danglingOld.length < 3) danglingOld.push(id); }
  }

  return {
    file,
    bytes: buf.length,
    frames: fr.frames,
    failedFrames: fr.failed,
    tornTail: fr.tornTail,
    lines: lines.length,
    parseErrors,
    seqSeen, seqGap, firstSeq, lastSeq: lastSeqVal,
    noMsgId, toolCalls, toolResults, danglingCalls: dangling,
    types,
    errors: fr.errors.slice(0, 3),
    healthy: fr.failed === 0 && seqGap === 0 && parseErrors === 0 && dangling === 0,
  };
}

function walk(dir, acc) {
  let ents = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return acc; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, acc);
    else if (e.name.endsWith(".jsonl.zstd")) acc.push(p);
    else if (e.name.endsWith(".tmp")) acc.push(p + "\u0000TMP");
  }
  return acc;
}

function main() {
  const args = process.argv.slice(2);
  const asJson = args.includes("--json");
  const li = args.indexOf("--limit");
  const limit = li >= 0 ? parseInt(args[li + 1], 10) || 50 : 50;
  const target = args.find((a) => !a.startsWith("--") && a !== String(limit));

  if (!target) { console.error("用法: node session-inspect.cjs <文件或目录> [--json] [--limit N]"); process.exit(2); }

  const stat = fs.existsSync(target) ? fs.statSync(target) : null;
  if (!stat) { console.error("路径不存在: " + target); process.exit(1); }

  let files = [];
  if (stat.isDirectory()) files = walk(target, []);
  else files.push(target);

  const tmps = files.filter((f) => f.endsWith("\u0000TMP")).map((f) => f.replace("\u0000TMP", ""));
  const sessions = files.filter((f) => f.endsWith(".jsonl.zstd"));

  // 只体检最新的 N 个（按修改时间），避免把几百个会话全解开
  sessions.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
  const picked = sessions.slice(0, limit);

  const results = picked.map((f) => { try { return inspectFile(f); } catch (e) { return { file: f, error: String(e && e.message || e) }; } });

  if (asJson) {
    console.log(JSON.stringify({ scanned: sessions.length, inspected: results.length, orphans: tmps.length, results }, null, 1));
    return;
  }

  console.log("会话体检：目录下共 " + sessions.length + " 个会话文件，本次体检最新 " + results.length + " 个；孤儿 .tmp " + tmps.length + " 个");
  let bad = 0;
  for (const r of results) {
    if (r.error) { console.log("  [读失败] " + path.basename(path.dirname(r.file)) + " → " + r.error); bad++; continue; }
    const tag = r.healthy ? "[OK]  " : "[注意]";
    if (!r.healthy) bad++;
    console.log(tag + " " + path.basename(path.dirname(r.file)) +
      "  帧 " + r.frames + (r.failedFrames ? "(坏帧 " + r.failedFrames + (r.tornTail ? "，疑似尾部半截" : "") + ")" : "") +
      "  行 " + r.lines +
      (r.seqSeen ? "  seq " + r.firstSeq + "→" + r.lastSeq + " 断档 " + r.seqGap : "  （无 seq 字段）") +
      "  缺 msgId " + r.noMsgId + "  悬空 tool/call " + r.danglingCalls);
    if (r.errors && r.errors.length) console.log("         " + r.errors.join("；"));
  }
  console.log("★ 结论：" + (bad === 0 ? "本次体检的会话都健康（更细的语义问题仍需人工/社区工具判断）。"
    : "有 " + bad + " 个会话存在可疑点 —— 本工具**只读**，不做会话改写；修复可用社区 dsh-session-surgeon（默认 dry-run、先备份）。"));
}

main();
