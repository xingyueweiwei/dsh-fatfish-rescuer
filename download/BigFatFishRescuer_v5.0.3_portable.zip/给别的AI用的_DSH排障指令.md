# 给别的 AI 用的 · DSH「打不开」排障指令

> 用途：当 DSH 出现 **「网页版死活打不开 / 一直转 / 反复报错 3080 / 过一会又好了然后又崩」** 时，
> 用**任何**一个会看日志的 AI（自己的、别人的、免费的都行）就能定位。
> 由「大肥鱼救星」整理（2026-09-18）。**本文件可以直接转给别人。**

---

## 怎么用（30 秒）

1. 出问题那台机器上，把【第一步】那段**整段**贴进 **PowerShell**，回车；再把屏幕上的输出**全部复制**。
2. 新建一个 AI 对话，把【第二步】的提示词**整段**粘进去，**紧接着**粘上刚才复制的输出，发送。
3. 它必须回你三样：**属于哪一类** + **证据是哪一行** + **一条能照着做的修法**。
   如果它说"重装 DSH / 删掉某个工具 / 把所有插件禁用"—— 直接否掉，让它重答（见【第四步】）。

> ⚠️ 【第一步】全是**只读命令**，不改你任何配置。它只是把"现在到底什么状态"打印出来。

---

## 第一步：收集证据（整段复制到 PowerShell 回车）

```powershell
$dsh = "$env:USERPROFILE\.dsh"
"==== 1) 系统 / node ===="
[System.Environment]::OSVersion.VersionString
node -v 2>$null
"`n==== 2) 谁在监听 3070~3210（dsh 常在这段）===="
Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
  Where-Object { $_.LocalPort -ge 3070 -and $_.LocalPort -le 3210 } |
  ForEach-Object {
    $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
    "{0}:{1}  PID={2}  进程={3}" -f $_.LocalAddress, $_.LocalPort, $_.OwningProcess, ($(if ($p) { $p.ProcessName } else { '?' }))
  }
"`n==== 3) dsh 相关进程 ===="
Get-Process node,cmd -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,StartTime | Format-Table -AutoSize
"`n==== 4) 桌面图标启动器配置 ===="
Get-Content "$dsh\whale-desktop-launcher\launcher.ini" -ErrorAction SilentlyContinue
"`n==== 5) 补丁层（插件登记都在这里）===="
"[home] $dsh\cordis.patch.yml"; Get-Content "$dsh\cordis.patch.yml" -ErrorAction SilentlyContinue
"[web]  $dsh\profiles\web\cordis.patch.yml"; Get-Content "$dsh\profiles\web\cordis.patch.yml" -ErrorAction SilentlyContinue
"`n==== 6) profile 清单 ===="
Get-Content "$dsh\profiles\web\package.json" -ErrorAction SilentlyContinue
"`n==== 7) 本地插件目录：有没有 package.json / 入口文件在不在 ===="
Get-ChildItem "$dsh\profiles\web\plugins" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $pj = Join-Path $_.FullName 'package.json'
  if (Test-Path $pj) {
    $t = Get-Content $pj -Raw -Encoding UTF8
    $main = ([regex]::Match($t, '"main"\s*:\s*"([^"]+)"')).Groups[1].Value
    $hasMain = ($main -ne '') -and (Test-Path (Join-Path $_.FullName ($main -replace '/','\')))
    "{0,-34} package.json=有  main={1}  入口存在={2}" -f $_.Name, ($(if($main){$main}else{'(无 main)'})), $hasMain
  } else {
    "{0,-34} package.json=**缺**（半装！）" -f $_.Name
  }
}
"`n==== 8) 最近一次 dsh 启动的输出（如果工具帮你启过）===="
foreach ($f in @("$dsh\big-fat-fish-rescuer\dsh-web.out.log", "$dsh\big-fat-fish-rescuer\dsh-web.out.log.err")) {
  if (Test-Path $f) { "--- $f"; Get-Content $f -Tail 40 -ErrorAction SilentlyContinue }
}
"`n==== 收集完毕：把以上全部输出复制下来 ===="
```

**再加一步（可选但最有用）**：自己手动启动一次，把报错抓下来：

```powershell
cd $env:USERPROFILE
npx @deepseek-ai/dsh web *> "$env:TEMP\dsh-boot.txt"
# 如果它成功打开网页了，等 10 秒后按 Ctrl+C 即可
Get-Content "$env:TEMP\dsh-boot.txt" -Tail 60
```
把 `dsh-boot.txt` 的尾部一起给 AI —— **插件树失败的那行错误就在这里**。

---

## 第二步：提示词（整段复制给那个 AI）

```
你现在是一位 DSH（DeepSeek Harness）排障工程师。用户的现象通常是：
「网页版 dsh 死活打不开 / 一直转圈 / 反复报错端口 3080 / 过一会又好了然后又崩 / 重装也没用」。
用户会把一段只读命令的输出（以及可能的启动日志）贴给你。

【第 0 条纪律：先读证据，再说话】
- 你必须**引用证据里的原句**（哪一行）来支持你的结论。找不到证据就明说"证据不足"，并列出你需要用户再补哪一条。
- **禁止**在没有任何证据的情况下建议：「重装 DSH」「删掉某个工具/救星」「把所有插件禁用」「换台电脑」「重装系统」。
  这些是聊天群里最流行、也最没用的建议，会让用户丢掉现场证据。
- 一次只给**一个**最可能的根因 + 一条修法（按顺序的第一个动作），不要一口气列十条让用户自己挑。
- 修法必须**具体到文件与那一行**，并告诉用户"改完怎么验证好了"。

【DSH 的关键事实（据此推理，不要凭空猜）】
1) DSH 的 web 服务默认端口 3080；端口可以改（环境变量 DSH_PORT，或文件
   %USERPROFILE%\.dsh\big-fat-fish-rescuer\port.txt）。用户心里记着 3080、而服务跑在别的端口，
   就会出现"我明明启动了却打不开页面"。
2) **插件树（plugin tree）失败会让 DSH 在启动阶段直接退出** ⇒ 页面打不开。
   日志里会有一行 `dsh: plugin tree failed to load: ...`，后面跟着真正的原因。
   必须**顺着这一行往下读**找第一处致命错误，先把那一处修掉；不要同时改多处。
3) 插件登记在补丁层 `cordis.patch.yml`（home 层 + 各 profile 层）。两种写法语义不同：
   · `- insert:` 下面的子项 id 是**创建**一个 row —— **同一个 id 出现两次会直接抛错、整棵树中止**；
   · 顶层的 `- id: xxx` 是**修改**已存在的 row —— 目标不存在时**只警告、不中止启动**。
4) 插件的 import 解析是**从插件文件自己的目录往上找 node_modules**。所以
   **装在 profile 目录之外的插件**（例如 `D:\plugins\某插件\`，靠补丁里的绝对路径挂上）
   看不到 DSH 自己那套 `@deepseek-ai/*` 包 ⇒ 报 `Cannot find package '...' imported from ...`
   （ERR_MODULE_NOT_FOUND）⇒ 插件树加载失败 ⇒ 页面打不开。这一类**重装 DSH 没用**，
   正解是把插件**装进 profile**（`dsh plugin --profile web add <包名或路径>`），
   或者先把那条 loader entry 禁掉让 DSH 能起来。
5) 本地插件还可以直接放在 `%USERPROFILE%\.dsh\profiles\web\plugins\<目录>`，
   但**必须有 package.json**（DSH 靠它拿 name/main）；缺 package.json 或 main 指向的文件不存在
   ⇒ 那一半起不来。
6) 端口两类错误要分清：
   · `EADDRINUSE` = 端口**被别的程序占着**（可能是上一次没退干净的 dsh）；
   · `EACCES` = **没有权限绑这个端口**，在 Windows 上常见于 3080 落在 Hyper-V/WSL2 的
     **保留端口区间** 里（netsh interface ipv4 show excludedportrange protocol=tcp 可查）。
     EACCES 的正解是**换端口**，不是重装。
7) 其他常见致命行与其含义：
   · `duplicate loader entry id: X` → 同一个 id 在 insert 子项里出现两次（多半是两个补丁文件各写了一条）
   · `cannot resolve profile bundle "X"` → 清单里列了 X、但找不到实体（插件被删/被移走）⇒ 悬空引用
   · `installed package X main entry is missing` → 包装了但入口文件不在（安装不完整）
   · `X: pending (waiting for service(s): Y)` → X 在等 Y，而 Y 被禁用/删掉了
   · `unknown prompt variable` → 记忆/提示词里出现了会被当模板变量插值的字面量（DSH 会拒绝启动）
   · `ENOENT` → 插件启动时要读/拷的资源文件不存在

【你要输出的格式（严格照这个格式，别写成散文）】
① 结论：属于哪一类（用上面第 6/7 条里的名字，或写"未归类，证据不足"）
② 证据：贴出你据以判断的那 1~3 行原文
③ 根因一句话：为什么会这样（要能对上证据）
④ 修法：**一条**，写清改哪个文件、加/删哪一行、或执行哪条命令；并说明"改完怎么验证"
⑤ 如果证据不足：明说还缺哪一条（例如"还要看 npx @deepseek-ai/dsh web 启动时的前 40 行输出"）

【不要做的事】
- 不要建议用户删掉救星/任何工具，除非证据直接指向那个工具（例如它的日志显示它在改配置）。
- 不要建议"先全部禁用插件再一个个打开"当作第一步（那是最后的二分法，会破坏现场）。
- 不要在没读日志前给出"可能是端口冲突"这种没有证据的猜测。
```

---

## 第三步：已知故障类速查（人看的；上面提示词里已包含）

| 日志里的关键行 | 类别 | 一条修法 |
|---|---|---|
| `Cannot find package '…' imported from …`（常见 `@deepseek-ai/…`） | 插件在 profile 外面 / 缺依赖 | 把插件装进 profile；或先禁掉那条 entry 让 DSH 起来 |
| `plugin tree failed to load: … failed to import loader entry X` | 某个插件起不来（**具体原因看它后面那句**） | 按后面的那句修；先禁用该 entry 恢复可用性 |
| `duplicate loader entry id: X` | 同一插件被登记两次 | 只留一条（两个补丁文件各写了一条时删掉一条） |
| `cannot resolve profile bundle "X"` | 悬空引用（列了但找不到） | 从清单里移除 X，或把 X 装回来 |
| `installed package X main entry is missing` | 安装不完整 | 重装**这一个**插件 |
| `X: pending (waiting for service(s): Y)` | X 在等被禁用/删掉的 Y | 恢复 Y，别删 X |
| `EADDRINUSE` | 端口被占 | 结束占用者，或换端口 |
| `EACCES` | 端口在 Windows 保留区间 | **换端口**（DSH_PORT / port.txt） |
| `unknown prompt variable` | 记忆/提示词里有字面量花括号 | 改掉那段文本里的 `{{…}}` |
| `ENOENT` | 资源文件缺失 | 重装该插件 |

---

## 第四步：如果 AI 给了这些建议，请直接否掉

- ❌「重装 DSH」—— 插件树失败时，插件还在原地，重装**不会**修好它（聊天记录里那位就是这么白折腾的）。
- ❌「把救星删掉」—— 除非证据显示它在改你的配置。它开着不动手时**不改任何文件**（有专门的验证脚本）。
- ❌「把插件全部禁用」—— 会破坏现场，之后再难定位；正确做法是"先定位到那一条 entry"。
- ❌「换个端口试试」—— 只在 `EADDRINUSE / EACCES` 证据下才是对的；插件问题换端口没用。

---

## 第五步：最省事的替代方案

如果那台机器上装了 **大肥鱼救星**，它已经把上面这套判据做成了按钮/命令：

```
大肥鱼救星.exe --classify "<日志文件路径>"
```
一条命令直接输出「哪一类 + 涉及哪个插件/包 + 该点哪个按钮」，
报告落在 `%USERPROFILE%\.dsh\big-fat-fish-rescuer\classify-report.txt`（UTF-8，可直接转发）。
